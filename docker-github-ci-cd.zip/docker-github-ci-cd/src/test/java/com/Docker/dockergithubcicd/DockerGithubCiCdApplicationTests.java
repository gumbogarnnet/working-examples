package com.Docker.dockergithubcicd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerGithubCiCdApplicationTests {

	@Test
	void contextLoads() {
	}

}
