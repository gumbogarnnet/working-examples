package com.Docker.dockergithubcicd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerGithubCiCdApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerGithubCiCdApplication.class, args);
	}

}
